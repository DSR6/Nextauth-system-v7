declare module "broken-link-checker";
