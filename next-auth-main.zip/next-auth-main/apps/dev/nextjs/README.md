# NextAuth.js Development App

This folder contains a Next.js app using NextAuth.js for local development. See the following section on how to start:

[Setting up local environment
](https://github.com/nextauthjs/.github/blob/main/CONTRIBUTING.md#setting-up-local-environment)
