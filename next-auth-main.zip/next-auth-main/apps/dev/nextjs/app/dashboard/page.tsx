export default function Page() {
  return <h1>This page is protected.</h1>
}
