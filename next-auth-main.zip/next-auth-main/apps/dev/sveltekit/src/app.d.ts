/// <reference types="@auth/sveltekit" />
