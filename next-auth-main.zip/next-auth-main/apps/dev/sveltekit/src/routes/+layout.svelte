<script lang="ts">
  import Header from "$components/header.svelte"
  import "../style.css"
</script>

<Header />
<slot />
