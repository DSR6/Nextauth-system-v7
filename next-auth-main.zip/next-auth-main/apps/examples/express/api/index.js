const { app } = await import("../src/app.js")

export default app
