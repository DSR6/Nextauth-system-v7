export { default } from "./Protected"
