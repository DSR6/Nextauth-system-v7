export { default } from "../[auth].js"
export const config = { runtime: "edge" }
