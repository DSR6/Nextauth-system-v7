<img src="public/img/logo-sm.png" alt="Logo" width="118" height="128" align="right" />

# Auth.js Docs

## Quick Start

First, run `pnpm i` to install the dependencies.

Then, run `pnpm dev` to start the development server and visit localhost:3000.

## License

This project is licensed under the MIT License.
