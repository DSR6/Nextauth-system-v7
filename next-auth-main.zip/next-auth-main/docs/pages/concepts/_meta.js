export default {
  index: "Overview",
  oauth: "How OAuth works",
  "session-strategies": "Session strategies",
  "database-models": "Database models",
}
