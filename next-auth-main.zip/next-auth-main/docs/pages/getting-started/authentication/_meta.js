export default {
  oauth: "OAuth",
  email: "Magic Links",
  credentials: "Credentials",
  webauthn: "WebAuthn 🔬",
}
