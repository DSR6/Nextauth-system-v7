export default {
  login: "Signin and Signout",
  "get-session": "Get Session",
  protecting: "Protecting Resources",
  "custom-pages": "Custom Pages",
}
