export default {
  "built-in-pages": "Built-in pages",
  signin: "Custom Signin",
  signout: "Custom Signout",
  error: "Custom Error",
}
