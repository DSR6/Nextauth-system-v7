export interface ChildrenProps {
  children: React.ReactNode
}
